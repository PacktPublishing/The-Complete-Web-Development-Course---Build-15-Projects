console.log('hi');
console.log('hello');
console.log('it\'s me');

//process variable: equivalent of document inside the browser
//console.log(process);
console.log(global);
//setTimeout
