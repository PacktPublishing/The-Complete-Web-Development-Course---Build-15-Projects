//const MAKE; 
const MAKE = 'Apple';
console.log(MAKE);

//MAKE = 'Samsung';


{
    const MAKE = 'Apple';
}

{
    const MAKE = 'Samsung';
}


const LANGUAGE = {
    name: 'JavaScript',
    version: 'ES5'
};
LANGUAGE.version = 'ES6';
//error only if you do LANGUAGE = something