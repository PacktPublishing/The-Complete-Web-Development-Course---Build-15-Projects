var firstname = 'Bill';
var lastname = 'Gates';

//ES5
console.log('Hello ' + firstname + ' ' + lastname + '!');

//ES6
console.log(`Hello ${firstname} ${lastname}!`);

//ES5
var text5 = 'Here is \na new line';
console.log(text5);

//ES6
const text6 = `Here is 
a new line`;
console.log(text6);